<?php
require 'templates/header.php';
?>

<a href="tambah_supplier.php"><button type="button" class="btn btn-primary m-4">tambah data suplieer</button></a>
<a href="tambah_barang.php"><button type="button" class="btn btn-primary m-4">tambah data barang</button></a>

<?php
require 'templates/footer.php';
?>